# Crosshue press kit

**Crosshue: Colour Crossword** is a crossword where the clues are colours. By Static Toad Labs, a one-person studio in Ireland. Out on iPhone and iPad on **Monday 9 November 2026**.

## Fact sheet

| | |
|---|---|
| Developer | Static Toad Labs (Chris O'Brien), Ireland |
| Release | 9 November 2026, worldwide except mainland China and Vietnam |
| Platforms | iPhone and iPad (iOS / iPadOS 17 or later) |
| Price | Free to play. Crosshue Pro, a one-off €4.99 / £4.99 / $4.99 purchase with Family Sharing, unlocks everything |
| Levels | 1,238, every one checked by a solver: 168 crossword levels in 12 worlds, 50 Stamp levels in 5 worlds, and the 1,020-print Puzzle Book |
| Free | 76 levels (the first two worlds, a taste of every other world, ten Puzzle Book prints) and both Dailies every day |
| Languages | English, German, French, Spanish, Italian, Brazilian Portuguese, Dutch, Japanese, Korean, Simplified Chinese |
| Privacy | No ads, no tracking, no accounts, works offline. App Privacy label: "Data Not Collected" |
| Apple features | Game Center (21 achievements, Daily leaderboards), Home Screen and Lock Screen widget, VoiceOver, Dynamic Type, Dark Mode |
| App Store | https://apps.apple.com/app/id6823928916 (live from launch day) |
| Contact | hello@statictoadlabs.com (press) · support@statictoadlabs.com (players) |

## One line

Crosshue is a crossword where the clues are colours.

## Short description (about 50 words)

Every row and column of the board gets one paint pot, and where they cross the paints mix: red and yellow make orange, yellow and blue make green. Pinned swatches show what each square must become. Deduce every pot, by logic alone, and the print comes out perfect. Two new Dailies every day.

## Long description

Crosshue is an original logic puzzle printed in a hand-made risograph style. Every row and column gets one paint pot; where lines cross, the paints mix like real paint. The pinned swatches are your clues. Work out what's in every pot and the print comes out perfect. Every puzzle has exactly one solution, and you can reach it by deduction alone. No guessing.

Each world adds one new rule. First come locked pots, thinner that lightens, ink that darkens, split lines that pour two ways, and premixed pots of orange, green and purple. Then come new kinds of clue: rings that name one paint in the mix, crossed-out misprints that rule a colour out, and twin and rival pots that must match or differ. It climbs from gentle 3×3 boards to fiendish 8×8 Broadsheets. Stamp mode swaps lines for shaped rubber stamps whose inks overprint where they overlap.

Two Dailies arrive every day, the same for everyone: a print and a stamp sheet. They climb from a gentle Monday to a fiendish Sunday, with streaks, spoiler-free sharing, Game Center leaderboards and a widget for your Home Screen or Lock Screen.

Crosshue is made for everyone. A colour game should be playable without seeing colour, so it has colour-blind patterns and component labels, full VoiceOver with adjustable paint pots, Dynamic Type, Reduce Motion and a Night paper mode.

It's free to play, with no ads and no tracking. A single Crosshue Pro purchase opens all 1,238 levels, every past Daily and unlimited hints, for the whole family.

## Key features

- An original mechanic: paints assigned to rows and columns, mixing where they cross
- 1,238 solver-checked levels: 12 crossword worlds, 5 Stamp worlds, the 1,020-print Puzzle Book
- Two Dailies every day, gentle Monday to fiendish Sunday, with streaks and leaderboards
- Hints that explain the reasoning in plain words, then pour the paint for you
- Colour-blind patterns, full VoiceOver, Dynamic Type, Reduce Motion, Night paper
- Home Screen and Lock Screen widget; Game Center achievements and leaderboards
- No ads, no tracking, no accounts, offline; one fair purchase, shared with family

## About Static Toad Labs

Static Toad Labs is an independent studio run by Chris O'Brien in Ireland. It makes small, polished puzzle games for iPhone and iPad, with fair prices and no tracking.

## Assets in this pack

- `icon/`: the app icon, square (as shipped) and rounded (for pages), 64 to 1024 px
- `art/`: the logo lockup and mark (transparent PNG), a 1200×630 social card, the App Store header art and a four-phone image
- `screenshots/`: iPhone (1320×2868) and iPad (2064×2752) full-size PNGs, plus 750 px JPEG copies of the iPhone set
- `icon/static-toad-labs-logo.png`: the studio logo

Screenshots of Pro content say so on the image. Please don't show prices taken from the screenshots: they vary by storefront.

## Promo codes

Writers and reviewers can ask for a code that unlocks Crosshue Pro: email hello@statictoadlabs.com.
