# Crosshue press kit

**Crosshue: Colour Crossword** is a colour logic puzzle, a bit like a nonogram: you work out which paint goes in each row and column from the colours where they cross. There are no words involved. By Static Toad Labs, a one-person studio in Ireland. Out on iPhone and iPad on **Monday 9 November 2026**.

App Store: https://apps.apple.com/app/id6823928916

Also in this pack: `FACT-SHEET.md` (the facts on one page), `PRESS-RELEASE.md` (a short release with a quote) and `APP-STORE-LINK.txt`.

## Fact sheet

| | |
|---|---|
| Developer | Static Toad Labs (Chris O'Brien), Ireland |
| Release | Monday 9 November 2026 |
| Where | UK, US, Canada and Australia: on the App Store now for pre-order. EU and Ireland: coming soon, pending Apple verification |
| Platforms | iPhone and iPad (iOS / iPadOS 17 or later) |
| Price | Free to play. Crosshue Pro is a one-time £4.99 / US$4.99 unlock (local equivalent in Canada and Australia), shared with Family Sharing. No subscription, no ads |
| Levels | 1,238, every one checked by a solver: 168 main-mode levels in 12 worlds, 50 Stamp levels in 5 worlds, and the 1,020-print Puzzle Book (720 main-mode, 300 Stamp) |
| Free | 76 levels (the first two worlds, a taste of every other world, ten Puzzle Book prints) and both Dailies every day |
| Pro adds | The other 1,162 levels: 120 main-mode levels, 32 Stamp levels and the rest of the Puzzle Book, plus every past Daily and unlimited hints |
| Languages | English, German, French, Spanish, Italian, Brazilian Portuguese, Dutch, Japanese, Korean, Simplified Chinese |
| Accessibility | Colour-blind friendly (patterns and component labels on every paint), full VoiceOver, Dynamic Type, Reduce Motion, Night paper |
| Privacy | No ads, no tracking, no accounts, works offline. App Privacy label: "Data Not Collected" |
| Apple features | Game Center (21 achievements, Daily leaderboards), Home Screen and Lock Screen widget, Dark Mode |
| App Store | https://apps.apple.com/app/id6823928916 |
| Contact | hello@statictoadlabs.com (press) · support@statictoadlabs.com (players) |

The main mode is called Crossword in the game because the paint lines cross, not because there are any clues to spell out.

## One line

Crosshue is a colour logic puzzle, a bit like a nonogram, where paints mix where rows and columns cross.

## Short description (about 50 words)

Every row and column of the board gets one paint pot, and where they cross the paints mix: red and yellow make orange, yellow and blue make green. Pinned swatches show what each square must become. Deduce every pot, by logic alone, and the print comes out perfect. Two new Dailies every day.

## Long description

Crosshue is an original logic puzzle printed in a hand-made risograph style. If you like nonograms, it will feel familiar: you reason line by line from the clues on the board. Here, though, every row and column gets one paint pot; where lines cross, the paints mix like real paint. The pinned swatches are your clues. Work out what's in every pot and the print comes out perfect. Every puzzle has exactly one solution, and you can reach it by deduction alone. No guessing, and no words.

Each world adds one new rule. First come locked pots, thinner that lightens, ink that darkens, split lines that pour two ways, and premixed pots of orange, green and purple. Then come new kinds of clue: rings that name one paint in the mix, crossed-out misprints that rule a colour out, and twin and rival pots that must match or differ. It climbs from gentle 2×2 boards to fiendish 8×8 Broadsheets. Stamp mode swaps lines for shaped rubber stamps whose inks overprint where they overlap.

Two Dailies arrive every day, the same for everyone: a print and a stamp sheet. They climb from a gentle Monday to a fiendish Sunday, with streaks, spoiler-free sharing, Game Center leaderboards and a widget for your Home Screen or Lock Screen.

Crosshue is made for everyone. A colour game should be playable without seeing colour, so it has colour-blind patterns and component labels, full VoiceOver with adjustable paint pots, Dynamic Type, Reduce Motion and a Night paper mode.

It's free to play, with no ads and no tracking: the first two worlds and both Dailies cost nothing. A single Crosshue Pro purchase, with no subscription, opens all 1,238 levels, every past Daily and unlimited hints, for the whole family.

## Key features

- An original mechanic: paints assigned to rows and columns, mixing where they cross
- Nonogram-style line logic with colour instead of numbers; no words, no guessing
- 1,238 solver-checked levels: 12 main-mode worlds, 5 Stamp worlds, the 1,020-print Puzzle Book
- Two Dailies every day, gentle Monday to fiendish Sunday, with streaks and leaderboards
- Hints that explain the reasoning in plain words, then pour the paint for you
- Colour-blind patterns, full VoiceOver, Dynamic Type, Reduce Motion, Night paper
- Home Screen and Lock Screen widget; Game Center achievements and leaderboards
- No ads, no tracking, no accounts, offline; one fair purchase, no subscription, shared with family

## About Static Toad Labs

Static Toad Labs is an independent studio run by Chris O'Brien in Ireland. It makes small, polished puzzle games for iPhone and iPad, with fair prices and no tracking.

## Assets in this pack

- `FACT-SHEET.md`, `PRESS-RELEASE.md`, `APP-STORE-LINK.txt`: text for writers
- `icon/`: the app icon, square (as shipped) and rounded (for pages), 64 to 1024 px
- `icon/static-toad-labs-logo.png`: the studio logo
- `art/`: the logo lockup and mark (transparent PNG), a 1200×630 social card, the App Store header art and a four-phone image
- `screenshots/full/` and `screenshots/web/`: iPhone (1320×2868) PNGs, plus 750 px JPEG copies
- `screenshots/ipad/full/`: iPad (2064×2752) PNGs, 01 to 11
- `screenshots/extra/daily-share/`: the Daily results screen (iPhone, 1320×2868), including Night paper, German and Japanese versions

Screenshots of Pro content say so on the image. The Pro screen (screenshot 11) lists only what Pro adds on top of the free levels, so it says 120 main-mode and 32 Stamp levels; the full game has 168 and 50. Please don't show prices taken from the screenshots: they vary by storefront.

## Promo codes

Writers and reviewers can ask for a code that unlocks Crosshue Pro: email hello@statictoadlabs.com.
