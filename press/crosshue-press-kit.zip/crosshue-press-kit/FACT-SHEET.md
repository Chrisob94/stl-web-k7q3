# Crosshue: fact sheet

**Crosshue: Colour Crossword** · iPhone and iPad · Static Toad Labs

- **What it is:** a colour logic puzzle, a bit like a nonogram. Each row and column gets one paint pot; where they cross, the paints mix. Work out every pot from the pinned colours. No words, no guessing.
- **Release:** Monday 9 November 2026
- **Where:** UK, US, Canada and Australia (pre-order now). EU and Ireland coming soon, pending Apple verification
- **Platforms:** iPhone and iPad, iOS / iPadOS 17 or later
- **Price:** free to play. Crosshue Pro is a one-time unlock (£4.99 / US$4.99, local equivalent in Canada and Australia), with Family Sharing. No subscription, no ads
- **Levels:** 1,238, all solver-checked
  - 168 main-mode levels in 12 worlds
  - 50 Stamp levels in 5 worlds
  - 1,020-print Puzzle Book (720 main-mode, 300 Stamp)
- **Free:** 76 levels (the first two worlds, a taste of every other world, ten Puzzle Book prints) and both Dailies every day
- **Pro adds:** the other 1,162 levels (120 main-mode, 32 Stamp, 1,010 Puzzle Book), every past Daily, unlimited hints
- **Dailies:** two a day, the same for everyone: a print and a stamp sheet, gentle Monday to fiendish Sunday
- **Accessibility:** colour-blind patterns and labels, full VoiceOver, Dynamic Type, Reduce Motion, Night paper
- **Languages:** English, German, French, Spanish, Italian, Brazilian Portuguese, Dutch, Japanese, Korean, Simplified Chinese
- **Privacy:** no ads, no tracking, no accounts, works offline ("Data Not Collected")
- **Apple features:** Game Center (21 achievements, Daily leaderboards), Home Screen and Lock Screen widget, Dark Mode
- **Developer:** Static Toad Labs (Chris O'Brien), Ireland
- **App Store:** https://apps.apple.com/app/id6823928916
- **Press:** https://statictoadlabs.com/press/
- **Contact:** hello@statictoadlabs.com (press, promo codes) · support@statictoadlabs.com (players)
