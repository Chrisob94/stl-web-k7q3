# Crosshue, a colour logic puzzle for iPhone and iPad, comes out on 9 November

**For release: now** · Static Toad Labs, Ireland

Hi, I'm Chris O'Brien. I make small puzzle games on my own as Static Toad Labs, and my new one, Crosshue, comes out on iPhone and iPad on Monday 9 November 2026. It's up for pre-order now in the UK, US, Canada and Australia. The EU and Ireland are coming soon, pending Apple verification.

Crosshue is a colour logic puzzle, a bit like a nonogram. Each row and column of the board gets one paint pot, and where they cross, the paints mix: red and yellow make orange, yellow and blue make green. A few squares are pinned to show the colour they have to end up. From those, you work out what's in every pot. There are no words to find, every puzzle has exactly one answer, and you can get there by logic alone.

Each world adds one new idea, like thinner, ink, locked pots or misprints, and there's a Stamp mode where shaped stamps overprint each other. There are over 1,200 levels in all, plus two Dailies every day that are the same for everyone.

"I wanted a puzzle where the moment it clicks is watching two colours meet and make the one you needed. It also had to work for colour-blind players, so every paint has its own pattern as well as its colour. It's free to start, and if you like it, one purchase gets you everything. No subscription and no ads."
— Chris O'Brien, Static Toad Labs

The first two worlds and both Dailies are free. Crosshue Pro is a one-time unlock for the rest, shared with Family Sharing. There are no ads and no tracking.

**App Store:** https://apps.apple.com/app/id6823928916
**Press kit:** https://statictoadlabs.com/press/
**Contact and promo codes:** hello@statictoadlabs.com

## About Static Toad Labs

Static Toad Labs is my one-person studio in Ireland. I make small puzzle games for iPhone and iPad, with fair prices and no tracking.
